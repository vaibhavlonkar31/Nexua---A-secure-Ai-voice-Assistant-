// Load face-api.js models
async function loadModels() {
    const MODEL_URL = "https://cdn.jsdelivr.net/npm/face-api.js/weights";
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
    await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
}

// Start webcam
async function startCamera(videoElement) {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        videoElement.srcObject = stream;
    } catch (error) {
        console.error("Error accessing webcam:", error);
    }
}

// Process face and return descriptor
async function processFace(videoElement) {
    const detections = await faceapi.detectSingleFace(videoElement, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor();

    if (!detections) {
        return null;
    }
    return Array.from(detections.descriptor);
}

// Recognize Face
async function recognizeFace(videoElement, statusElement) {
    statusElement.textContent = "Checking face...";
    const descriptor = await processFace(videoElement);
    if (!descriptor) {
        statusElement.textContent = "No face detected. Try again!";
        return;
    }

    fetch("/recognize/", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": getCSRFToken() },
        body: JSON.stringify({ descriptor })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            statusElement.textContent = `Welcome, ${data.name}! Redirecting...`;
            setTimeout(() => { window.location.href = "/main"; }, 2000);
        } else {
            statusElement.textContent = "Face not recognized. Try registering.";
        }
    })
    .catch(error => { console.error("Error:", error); });
}

// Register New Face
async function registerFace(videoElement, statusElement) {
    const name = prompt("Enter your name:");
    if (!name) return;

    statusElement.textContent = "Registering face...";
    const descriptor = await processFace(videoElement);
    if (!descriptor) {
        statusElement.textContent = "No face detected. Try again!";
        return;
    }

    fetch("/addface/", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": getCSRFToken() },
        body: JSON.stringify({ name, descriptor })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            statusElement.textContent = "Face registered successfully!";
        } else {
            statusElement.textContent = "Error registering face.";
        }
    })
    .catch(error => { console.error("Error:", error); });
}

// CSRF Token Helper
function getCSRFToken() {
    return document.cookie.split('; ').find(row => row.startsWith('csrftoken='))?.split('=')[1];
}

// Initialize the script
async function initFaceRecognition(videoElement, captureBtn, registerBtn, statusElement) {
    await loadModels();
    await startCamera(videoElement);

    captureBtn.addEventListener("click", () => recognizeFace(videoElement, statusElement));
    registerBtn.addEventListener("click", () => registerFace(videoElement, statusElement));
}

// Export functions if needed for other scripts
export { initFaceRecognition };
