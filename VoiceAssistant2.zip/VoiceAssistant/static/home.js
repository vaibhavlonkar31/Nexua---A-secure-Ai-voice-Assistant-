document.addEventListener("DOMContentLoaded", function () {
    const statusElement = document.getElementById("status");

    function startVoiceRecognition() {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = "en-US";
        recognition.start();

        recognition.onstart = function () {
            statusElement.textContent = "Listening...";
        };

        recognition.onresult = function (event) {
            let speechResult = event.results[0][0].transcript.toLowerCase();
            console.log("Recognized speech:", speechResult);

            if (speechResult.includes("hello nexus")) {
                statusElement.textContent = "Authentication Successful! Redirecting...";
                setTimeout(() => {
                    window.location.href = "/facereco";
                }, 2000);
            } else {
                statusElement.textContent = "Try again. Say 'Hello Nexus'.";
                recognition.start();
            }
        };

        recognition.onerror = function () {
            recognition.start();
        };

        recognition.onend = function () {
            recognition.start();
        };
    }

    // Start voice recognition automatically
    startVoiceRecognition();
});
