async function sendVoiceCommand(command) {
    try {
        const response = await fetch("/dashboard/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": getCSRFToken(),
            },
            body: JSON.stringify({ command: command }),
        });

        if (!response.ok) {
            throw new Error(`HTTP Error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log("✅ Nexus Response:", data.message);
        displayMessage(data.message, "nexus-message");
    } catch (error) {
        console.error("❌ Error:", error);
        displayMessage("An error occurred. Please try again.", "error-message");
    }
}

function getCSRFToken() {
    const token = document.cookie.split("; ").find(row => row.startsWith("csrftoken="));
    return token ? token.split("=")[1] : "";
}

function displayMessage(message, className) {
    let chatBox = document.getElementById("chatBox");
    let msgDiv = document.createElement("div");
    msgDiv.className = "message " + className;
    msgDiv.innerText = message;
    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;

    if (className === "nexus-message") {
        speak(message); // Speak only Nexus's response
    }
}

function speak(text) {
    if (!text) return;

    const speech = new SpeechSynthesisUtterance(text);
    speech.lang = "en-US";
    speech.rate = 1;
    speech.pitch = 1.2;

    const voices = speechSynthesis.getVoices();
    const femaleVoice = voices.find(voice => voice.name.toLowerCase().includes("female") || voice.name.includes("Zira"));

    if (femaleVoice) {
        speech.voice = femaleVoice;
    }

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(speech);
}

function startVoiceRecognition() {
    if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
        console.error("⚠️ Speech Recognition not supported in this browser.");
        return;
    }

    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;

    const waveContainer = document.getElementById("waveContainer");

    waveContainer.style.display = "block"; // Show wave animation
    recognition.start();

    recognition.onresult = async function (event) {
        let voiceText = event.results[0][0].transcript.toLowerCase();
        console.log("🎤 User Said:", voiceText);

        const wakeWords = ["hello nexus", "hey nexus", "wake up nexus"];

        if (wakeWords.some(phrase => voiceText.includes(phrase))) {
            displayMessage("Hello! How can I assist you?", "nexus-message");
        } else {
            displayMessage(voiceText, "user-message");
            await sendVoiceCommand(voiceText);
        }
    };

    recognition.onerror = function (event) {
        console.error("⚠️ Speech Recognition Error:", event.error);
    };

    recognition.onend = function () {
        console.log("🛑 Recognition ended. Restarting...");
        waveContainer.style.display = "none"; // Hide wave animation
        setTimeout(startVoiceRecognition, 1000);
    };
}

// Start listening when the page loads
window.onload = function () {
    setTimeout(startVoiceRecognition, 1000);
};



