function playGeneratedSpeech() {
    if (!window.speechSynthesis) {
        console.error("Speech synthesis is not supported in this browser.");
        return;
    }

    // Stop any stuck speech
    window.speechSynthesis.cancel();

    let now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12;
    let timeString = `The time is ${hours}:${minutes < 10 ? "0" + minutes : minutes} ${ampm}.`;
    let dateString = `Today is ${now.toLocaleString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}.`;

    let speechText = `Hello! I am Nexus AI. ${timeString} ${dateString} How can I assist you?`;
    let speech = new SpeechSynthesisUtterance(speechText);

    function speakOnce() {
        let voices = speechSynthesis.getVoices();
        if (voices.length === 0) {
            console.warn("Voices not loaded, retrying...");
            return;
        }

        // Pick the best available voice
        let preferredVoice = voices.find(v => v.name.includes("Microsoft Zira"))
                            || voices.find(v => v.name.includes("Google US English"))
                            || voices.find(v => v.name.includes("Microsoft"))
                            || voices[0];

        console.log("Selected voice:", preferredVoice.name);
        speech.voice = preferredVoice;
        speech.volume = 1;
        speech.rate = 1;
        speech.pitch = 1.2;

        // Speak after a short delay
        setTimeout(() => {
            window.speechSynthesis.speak(speech);
        }, 500);

        speech.onend = function () {
            console.log("Speech finished. Redirecting...");
            window.location.href = "/home/";
        };

        // Prevent multiple calls
        speechSynthesis.onvoiceschanged = null;
    }

    // Speak only if voices are available
    if (speechSynthesis.getVoices().length > 0) {
        speakOnce();
    } else {
        speechSynthesis.onvoiceschanged = speakOnce;
    }
}

// Ensure the script runs only once after page loads
document.addEventListener("DOMContentLoaded", () => {
    console.log("DOM fully loaded. Starting speech...");
    setTimeout(playGeneratedSpeech, 2000);
    document.removeEventListener("DOMContentLoaded", playGeneratedSpeech); // Prevent duplicate calls
});
