import openai

# Initialize OpenAI client with your API key
client = openai.OpenAI(api_key="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")  # Replace with your actual API key

try:
    response = client.chat.completions.create(
        model="gpt-4o-mini",  # Change to "gpt-4o" or another model if needed
        messages=[{"role": "user", "content": "machine learning ?"}],
        max_tokens=50
    )
    print("API Response:", response.choices[0].message.content.strip())

except openai.OpenAIError as e:  # Catch OpenAI-specific errors
    print("API Error:", e)
except Exception as e:
    print("Other Error:", e)
