from django.shortcuts import render
from django.conf import settings
import pyttsx3
import datetime
import io
import os
import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from pydub import AudioSegment






###intro
from django.shortcuts import render

def intro(request):
    return render(request, 'intro.html')

def home(request):
    return render(request, 'home.html')

def facereco(request):
    return render(request,'facereco.html')

def main(request):
    return render(request,'dashboard.html')

#########################################dashboard logic###########
        
import json
import os
import psutil
import subprocess
import pyttsx3
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import openai  # OpenAI API for ChatGPT

# OpenAI API Key (Replace with your actual key)
OPENAI_API_KEY = "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"

import json
import os
import psutil
import subprocess
import pyttsx3
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import openai



# Initialize OpenAI Client
client = openai.OpenAI(api_key=OPENAI_API_KEY)

# Initialize Text-to-Speech engine
engine = pyttsx3.init()
engine.setProperty('rate', 170)

# Function to speak
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Predefined application commands
commands = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "chrome": "chrome.exe",
    "file explorer": "explorer.exe",
    "command prompt": "cmd.exe",
    "task manager": "taskmgr.exe",
}

def ask_chatgpt(query):
    """Query OpenAI ChatGPT and return the response."""
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": query}
            ],
            max_tokens=30  # Adjusted to allow longer responses
        )
        answer = response.choices[0].message.content.strip()
        
        print(f"ChatGPT Response: {answer}")  # Debugging log
        return answer

    except Exception as e:
        return f"Error with ChatGPT API: {e}"

@csrf_exempt
def dashboard(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            command_text = data.get("command", "").lower()

            print(f"Received command: {command_text}")  # Debugging log

            if command_text.startswith("open"):
                app_name = command_text.replace("open", "").strip()
                if app_name in commands:
                    try:
                        subprocess.Popen(commands[app_name], shell=True, start_new_session=True)
                        # REMOVE TTS TEMPORARILY TO CHECK IF IT'S CAUSING THE ERROR
                        return JsonResponse({"status": "success", "message": f"Opening {app_name}"})
                    except Exception as e:
                        return JsonResponse({"status": "error", "message": f"Failed to open {app_name}: {str(e)}"}, status=500)

            elif command_text.startswith("close"):
                app_name = command_text.replace("close", "").strip()
                if app_name in commands:
                    found = False
                    try:
                        for process in psutil.process_iter(attrs=['pid', 'name']):
                            if commands[app_name].lower() in process.info['name'].lower():
                                os.system(f"taskkill /PID {process.info['pid']} /F")
                                found = True
                        # REMOVE TTS TEMPORARILY
                        return JsonResponse({"status": "success", "message": f"Closing {app_name}" if found else f"{app_name} is not running"})
                    except Exception as e:
                        return JsonResponse({"status": "error", "message": f"Failed to close {app_name}: {str(e)}"}, status=500)

            # If command not recognized, query ChatGPT
            chatgpt_response = ask_chatgpt(command_text)
            
            print(f"ChatGPT Response: {chatgpt_response}")  # Debugging

            # TEMPORARILY DISABLE SPEECH
            # speak(chatgpt_response)  <-- COMMENT THIS LINE

            return JsonResponse({"status": "success", "message": chatgpt_response})

        except json.JSONDecodeError:
            return JsonResponse({"status": "error", "message": "Invalid JSON format"}, status=400)

        except Exception as e:
            print("Django Error:", str(e))  # Log the full error
            return JsonResponse({"status": "error", "message": f"Server error: {str(e)}"}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request method"}, status=405)



########################for face#######################################

import os
import base64
import cv2
import numpy as np
from deepface import DeepFace
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# Folder to store registered faces
KNOWN_FACES_DIR = "media/known_faces"
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)

# Load known faces
def load_known_faces():
    return [os.path.join(KNOWN_FACES_DIR, filename) for filename in os.listdir(KNOWN_FACES_DIR)]

@csrf_exempt
def recognize_face(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            image_data = data.get("image")

            if not image_data:
                return JsonResponse({"error": "No image provided"}, status=400)

            # Convert base64 to image
            image_data = base64.b64decode(image_data.split(",")[1])
            np_arr = np.frombuffer(image_data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            # Save temporary image
            temp_path = "media/temp.jpg"
            cv2.imwrite(temp_path, frame)

            known_faces = load_known_faces()
            if not known_faces:
                return JsonResponse({"error": "No registered faces found"}, status=400)

            # Compare with registered faces
            for face_path in known_faces:
                result = DeepFace.verify(img1_path=temp_path, img2_path=face_path, model_name="Facenet", enforce_detection=False)
                if result["verified"]:
                    name = os.path.basename(face_path).split('.')[0]
                    return JsonResponse({"success": True, "name": name})

            return JsonResponse({"success": False, "error": "Face not recognized"}, status=401)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

@csrf_exempt
def add_face(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get("name")
            image_data = data.get("image")

            if not name or not image_data:
                return JsonResponse({"error": "Name and image are required"}, status=400)

            # Convert base64 to image
            image_data = base64.b64decode(image_data.split(",")[1])
            np_arr = np.frombuffer(image_data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            # Save image with username
            file_path = os.path.join(KNOWN_FACES_DIR, f"{name}.jpg")
            cv2.imwrite(file_path, frame)

            return JsonResponse({"success": True, "message": "Face registered successfully!"})

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

